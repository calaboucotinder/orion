from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.dialects.mysql import JSON # Import JSON type for MySQL
from datetime import datetime

db = SQLAlchemy()

class Usuario(db.Model):
    __tablename__ = 'usuarios' # Explicitly set table name

    id = db.Column(db.Integer, primary_key=True)
    nick = db.Column(db.String(255), unique=True, nullable=False)
    telefone = db.Column(db.String(50), unique=True, nullable=False) # Consider length and format validation
    codigo_acesso = db.Column(db.String(50), unique=True, nullable=False)
    respostas_quiz = db.Column(JSON, nullable=True) # Use JSON type
    resumo_gerado = db.Column(db.Text, nullable=True)
    idioma = db.Column(db.String(10), nullable=False, default='pt') # Default language 'pt'
    data_criacao = db.Column(db.TIMESTAMP, nullable=False, default=datetime.utcnow)
    data_atualizacao = db.Column(db.TIMESTAMP, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f'<Usuario {self.nick}>'

