import requests # Use requests for HTTP calls
import os
import uuid
import json # To handle JSON data
from flask import Blueprint, request, jsonify
from src.models.user import db, Usuario # Import db and Usuario model

quiz_bp = Blueprint("quiz", __name__)

# Read personality
personality = "Você é um assistente prestativo." # Default personality
try:
    # Construct the absolute path to person_sys.txt relative to this file's directory
    personality_file_path = os.path.join(os.path.dirname(__file__), 'person_sys.txt')
    with open(personality_file_path, 'r', encoding='utf-8') as f:
        personality = f.read().strip()
except FileNotFoundError:
    print("AVISO: Arquivo person_sys.txt não encontrado. Usando personalidade padrão.")
except Exception as e:
    print(f"Erro ao ler arquivo de personalidade: {e}")


# API Key and Endpoint Configuration
API_KEY = os.getenv("GOOGLE_API_KEY") # Read directly from env var
GEMINI_API_ENDPOINT = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={API_KEY}"

if not API_KEY:
    print("AVISO: Chave da API Gemini não configurada para Quiz. Use a variável de ambiente GOOGLE_API_KEY.")

@quiz_bp.route("/submit", methods=["POST"])
def submit_quiz():
    data = request.get_json()
    nick = data.get("nick")
    telefone = data.get("telefone")
    answers = data.get("answers")
    language = data.get("language", "pt")

    if not nick or not telefone or not answers:
        return jsonify({"error_key": "MISSING_QUIZ_DATA"}), 400

    if not nick.startswith("@"):
        nick = "@" + nick

    # Check if API key is configured before trying to use Gemini
    if not API_KEY:
        print("Erro: Chave da API Gemini não configurada.")
        return jsonify({"error_key": "API_KEY_MISSING"}), 500

    try:
        # 1. Generate Summary using Gemini via HTTP Request

        # Construct the prompt with personality and desired format
        prompt_parts = [
            personality, # Add personality instruction
            f"Gere um resumo personalizado em {language} para o cliente com nick '{nick}'. As respostas do quiz foram:",
        ]
        answers_text = ""
        for q_id, answer in answers.items():
            answers_text += f"- Pergunta {q_id}: {answer}\n"

        prompt_parts.append(answers_text)
        prompt_parts.append(f"O resumo deve seguir o formato: 'Resumo para {nick}: [resumo personalizado baseado nas respostas]'.")

        full_prompt = "\n".join(prompt_parts)

        # Prepare payload for HTTP request
        payload = {
            "contents": [{
                "parts":[{"text": full_prompt}]
            }]
        }

        headers = {
            'Content-Type': 'application/json'
        }

        print(f"\n--- Enviando prompt para Gemini via HTTP (Usuário: {nick}) ---\n{full_prompt}\n--------------------------------------")

        # Make the HTTP POST request
        response = requests.post(GEMINI_API_ENDPOINT, headers=headers, json=payload)
        response.raise_for_status() # Raise an exception for bad status codes (4xx or 5xx)

        # Extract summary from response
        response_data = response.json()
        # Navigate through the response structure to get the text
        # Expected structure: response_data['candidates'][0]['content']['parts'][0]['text']
        summary = ""
        try:
            summary = response_data['candidates'][0]['content']['parts'][0]['text']
        except (KeyError, IndexError, TypeError) as e:
            print(f"Erro ao extrair texto da resposta da API Gemini: {e}")
            print(f"Resposta recebida: {response_data}")
            raise ValueError("Formato de resposta inesperado da API Gemini")

        print(f"\n--- Resumo recebido da Gemini ---\n{summary}\n---------------------------------")

        # 2. Generate Unique Access Code
        access_code = str(uuid.uuid4())[:8].upper()

        # 3. Find existing user or create a new one
        user = Usuario.query.filter_by(nick=nick, telefone=telefone).first()

        if user:
            print(f"Atualizando usuário existente: {nick}")
            user.respostas_quiz = answers
            user.resumo_gerado = summary
            user.codigo_acesso = access_code
            user.idioma = language
        else:
            print(f"Criando novo usuário: {nick}")
            user = Usuario(
                nick=nick,
                telefone=telefone,
                respostas_quiz=answers,
                resumo_gerado=summary,
                codigo_acesso=access_code,
                idioma=language
            )
            db.session.add(user)

        # 4. Commit changes to DB
        db.session.commit()
        print(f"Resultado salvo no DB para {nick}. Código de acesso: {access_code}")

        return jsonify({
            "message": "Quiz finalizado e resumo gerado!",
            "summary": summary,
            "access_code": access_code
        }), 200

    except requests.exceptions.RequestException as e:
        print(f"Erro na requisição HTTP para a API Gemini: {e}")
        return jsonify({"error_key": "GEMINI_API_REQUEST_FAILED"}), 500
    except Exception as e:
        db.session.rollback()
        print(f"Erro ao processar quiz, chamar Gemini API ou salvar no DB: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({"error_key": "QUIZ_PROCESSING_FAILED"}), 500

