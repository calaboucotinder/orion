import requests # Use requests for HTTP calls
import os
import json # To handle JSON data
from flask import Blueprint, request, jsonify
from src.models.user import db, Usuario # Import db and Usuario model

chat_bp = Blueprint("chat", __name__)

# Read personality
personality = "Você é um assistente prestativo." # Default personality
try:
    # Construct the absolute path to person_sys.txt relative to this file's directory
    personality_file_path = os.path.join(os.path.dirname(__file__), 'person_sys.txt')
    with open(personality_file_path, 'r', encoding='utf-8') as f:
        personality = f.read().strip()
except FileNotFoundError:
    print("AVISO: Arquivo person_sys.txt não encontrado no chat. Usando personalidade padrão.")
except Exception as e:
    print(f"Erro ao ler arquivo de personalidade no chat: {e}")

# API Key and Endpoint Configuration
API_KEY = os.getenv("GOOGLE_API_KEY") # Read directly from env var
# Use the generateContent endpoint for chat as well, managing history manually
GEMINI_API_ENDPOINT = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={API_KEY}"

if not API_KEY:
    print("AVISO: Chave da API Gemini não configurada para Chat. Use a variável de ambiente GOOGLE_API_KEY.")

# In-memory storage for chat history (now stores list of content objects)
chat_histories = {}

@chat_bp.route("/message", methods=["POST"])
def handle_chat_message():
    data = request.get_json()
    nick = data.get("nick")
    telefone = data.get("telefone")
    message = data.get("message")

    if not message or not nick or not telefone:
        return jsonify({"error_key": "MISSING_CHAT_DATA"}), 400

    if not nick.startswith("@"):
        nick = "@" + nick

    # Check if API key is configured before trying to use Gemini
    if not API_KEY:
        print("Erro: Chave da API Gemini não configurada.")
        return jsonify({"error_key": "API_KEY_MISSING"}), 500

    try:
        # 1. Retrieve User Context (Summary) from Database
        user = Usuario.query.filter_by(nick=nick, telefone=telefone).first()
        if not user:
             return jsonify({"error_key": "USER_NOT_FOUND"}), 404
        if not user.resumo_gerado:
             return jsonify({"error_key": "SUMMARY_NOT_GENERATED"}), 404

        user_summary = user.resumo_gerado
        user_language = user.idioma
        user_key = f"{nick}_{telefone}"

        # 2. Initialize or Retrieve Chat History
        if user_key not in chat_histories:
            # Incorporate Orion Neo personality and context
            system_instruction = (
                 f"{personality}\n\n"
                 f"Você está conversando com o usuário {nick}. O resumo gerado anteriormente sobre ele/ela é: "
                 f"\n--- RESUMO DO USUÁRIO ---\n{user_summary}\n--- FIM DO RESUMO ---"
                 f"\nConverse com {nick} com base nesse resumo, respondendo às perguntas dele(a) e ajudando-o(a) a explorar mais sobre si mesmo(a). "
                 f"Responda sempre em {user_language}. Mantenha a conversa fluindo com sua personalidade definida."
            )
            print(f"\n--- Iniciando Chat com Orion (Usuário: {nick}) ---\nContexto Inicial Enviado (com personalidade Orion Neo).\n--------------------------------------")

            # Generate a first greeting message based on personality via HTTP
            greeting_prompt = f"{personality}\n\nVocê está iniciando uma conversa com {nick} (idioma: {user_language}) baseado no resumo dele(a): {user_summary}. Dê uma saudação inicial curta e convidativa, seguindo sua personalidade."
            greeting_payload = {"contents": [{"parts":[{"text": greeting_prompt}]}]}
            headers = {'Content-Type': 'application/json'}
            greeting_response_raw = requests.post(GEMINI_API_ENDPOINT, headers=headers, json=greeting_payload)
            greeting_response_raw.raise_for_status()
            greeting_data = greeting_response_raw.json()
            try:
                greeting = greeting_data['candidates'][0]['content']['parts'][0]['text']
            except (KeyError, IndexError, TypeError):
                greeting = f"Olá, {nick}! Sou Orion. Como posso ajudar?" # Fallback greeting
                print(f"Erro ao extrair saudação da API, usando fallback. Resposta: {greeting_data}")
            print(f"Saudação inicial gerada: {greeting}")

            # Initialize history with system instruction and first greeting
            chat_histories[user_key] = [
                {"role": "user", "parts": [{"text": system_instruction}]}, # Treat system instruction as first user message for context
                {"role": "model", "parts": [{"text": greeting}]}
            ]
            # Return only the greeting for the first message
            return jsonify({"reply": greeting}), 200

        # 3. Append user message to history
        chat_histories[user_key].append({"role": "user", "parts": [{"text": message}]})

        # 4. Send History + New Message to Gemini via HTTP
        payload = {
            "contents": chat_histories[user_key]
            # Add generationConfig or safetySettings if needed
        }
        headers = {'Content-Type': 'application/json'}

        print(f"\n--- Enviando histórico + mensagem para Orion via HTTP (Usuário: {nick}) ---")
        # print(json.dumps(payload, indent=2)) # Optional: print full payload for debugging
        print(f"Última mensagem: {message}")
        print("--------------------------------------")

        response_raw = requests.post(GEMINI_API_ENDPOINT, headers=headers, json=payload)
        response_raw.raise_for_status()
        response_data = response_raw.json()

        # Extract AI response
        try:
            ai_response = response_data['candidates'][0]['content']['parts'][0]['text']
        except (KeyError, IndexError, TypeError) as e:
            print(f"Erro ao extrair texto da resposta da API Gemini no chat: {e}")
            print(f"Resposta recebida: {response_data}")
            raise ValueError("Formato de resposta inesperado da API Gemini")

        print(f"\n--- Resposta recebida de Orion ---\n{ai_response}\n---------------------------------")

        # 5. Append AI response to history
        chat_histories[user_key].append({"role": "model", "parts": [{"text": ai_response}]})

        # 6. Return AI Response
        return jsonify({"reply": ai_response}), 200

    except requests.exceptions.RequestException as e:
        print(f"Erro na requisição HTTP para a API Gemini no chat: {e}")
        # Clean up history for this user on API error?
        # if user_key in chat_histories: del chat_histories[user_key]
        return jsonify({"error_key": "GEMINI_API_REQUEST_FAILED"}), 500
    except Exception as e:
        print(f"Erro ao processar mensagem do chat ou chamar Gemini API: {e}")
        import traceback
        traceback.print_exc()
        # Clean up history for this user on general error?
        # if user_key in chat_histories: del chat_histories[user_key]
        return jsonify({"error_key": "CHAT_PROCESSING_FAILED"}), 500

@chat_bp.route("/clear", methods=["POST"])
def clear_chat():
    data = request.get_json()
    nick = data.get("nick")
    telefone = data.get("telefone")

    if not nick or not telefone:
        return jsonify({"error_key": "MISSING_NICK_PHONE"}), 400

    if not nick.startswith("@"):
        nick = "@" + nick

    user_key = f"{nick}_{telefone}"
    # Use chat_histories instead of active_chats
    if user_key in chat_histories:
        del chat_histories[user_key]
        print(f"Histórico de chat em memória limpo para {nick}")
        return jsonify({"message": "Histórico de chat limpo."}), 200
    else:
        return jsonify({"error_key": "NO_ACTIVE_CHAT"}), 404

